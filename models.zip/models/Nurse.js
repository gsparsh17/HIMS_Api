const mongoose = require('mongoose');

const nurseSchema = new mongoose.Schema({
  // Hospital context
  hospital_ids: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital',
    required: true 
  }],
  primary_hospital_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital',
    required: true 
  },
  
  // Personal information
  first_name: { type: String, required: true },
  last_name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  phone: { type: String, required: true },
  
  // Professional information
  employee_id: {
    type: String,
    unique: true
  },
  department_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Department' 
  },
  shift_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Shift' 
  },
  
  // Additional fields
  date_of_birth: { type: Date },
  gender: {
    type: String,
    enum: ['male', 'female', 'other']
  },
  address: { type: String },
  emergency_contact: { type: String },
  emergency_phone: { type: String },
  
  // Qualifications
  qualification: { type: String },
  specialization: { type: String },
  license_number: { type: String, unique: true },
  years_of_experience: { type: Number },
  
  // Employment details
  employment_type: {
    type: String,
    enum: ['Full-time', 'Part-time', 'Contract', 'Trainee'],
    default: 'Full-time'
  },
  designation: {
    type: String,
    enum: ['Staff Nurse', 'Senior Nurse', 'Head Nurse', 'Nurse Supervisor', 'Nurse Manager', 'Trainee Nurse']
  },
  salary: { type: Number },
  
  // Status
  status: {
    type: String,
    enum: ['Active', 'Inactive', 'On Leave', 'Suspended', 'Resigned'],
    default: 'Active'
  },
  
  // Timestamps
  joined_at: { type: Date, default: Date.now },
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now }
});

// Generate employee ID before saving
nurseSchema.pre('save', async function(next) {
  try {
    if (!this.employee_id) {
      const hospital = await mongoose.model('Hospital').findById(this.primary_hospital_id);
      if (!hospital || !hospital.hospitalID) {
        throw new Error('Primary hospital not found or invalid hospital ID');
      }

      function generateRandomCode(length = 4) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
          result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
      }

      this.employee_id = `${hospital.hospitalID}-NURSE-${generateRandomCode(4)}`;
    }
    
    // Ensure primary_hospital_id is in hospital_ids array
    if (this.hospital_ids && this.hospital_ids.length > 0 && 
        !this.hospital_ids.includes(this.primary_hospital_id)) {
      this.hospital_ids.push(this.primary_hospital_id);
    }
    
    // Update timestamp
    this.updated_at = new Date();
    
    next();
  } catch (err) {
    next(err);
  }
});

// Indexes for better performance
nurseSchema.index({ primary_hospital_id: 1 });
nurseSchema.index({ hospital_ids: 1 });
nurseSchema.index({ email: 1 });
nurseSchema.index({ phone: 1 });
nurseSchema.index({ employee_id: 1 });
nurseSchema.index({ license_number: 1 });
nurseSchema.index({ status: 1 });
nurseSchema.index({ department_id: 1 });

// Virtual for full name
nurseSchema.virtual('full_name').get(function() {
  return `${this.first_name} ${this.last_name}`;
});

module.exports = mongoose.model('Nurse', nurseSchema);