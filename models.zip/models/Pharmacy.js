const mongoose = require('mongoose');

const pharmacySchema = new mongoose.Schema({
  // Pharmacy can be linked to multiple hospitals or groups
  hospital_ids: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital' 
  }],
  group_ids: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'HospitalGroup' 
  }],
  is_global_pharmacy: {
    type: Boolean,
    default: false
  },
  pharmacyId: { 
    type: String, 
    unique: true 
  },
  name: { 
    type: String, 
    required: true 
  },
  licenseNumber: { 
    type: String, 
    required: true, 
    unique: true 
  },
  email: { 
    type: String, 
    required: true, 
    unique: true 
  },
  phone: { 
    type: String 
  },
  address: { 
    type: String 
  },
  pharmacy_type: {
    type: String,
    enum: ['inhouse', 'external', 'chain', 'franchise'],
    default: 'inhouse'
  },
  is_central_pharmacy: {
    type: Boolean,
    default: false
  },
  manager_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  operational_hours: {
    open: String,
    close: String,
    days: [String]
  },
  status: { 
    type: String, 
    enum: ['Active', 'Inactive', 'Under Maintenance'], 
    default: 'Active' 
  },
  registeredAt: { 
    type: Date, 
    default: Date.now 
  }
}, { 
  timestamps: true 
});

// Generate pharmacy ID
pharmacySchema.pre('save', async function (next) {
  try {
    if (!this.pharmacyId) {
      function generatePharmacyId() {
        const prefix = 'PHARM';
        const randomNum = Math.floor(1000 + Math.random() * 9000);
        return `${prefix}-${randomNum}`;
      }
      
      this.pharmacyId = generatePharmacyId();
    }
    next();
  } catch (err) {
    next(err);
  }
});

// Indexes
pharmacySchema.index({ hospital_ids: 1 });
pharmacySchema.index({ group_ids: 1 });
pharmacySchema.index({ is_global_pharmacy: 1 });
pharmacySchema.index({ pharmacy_type: 1 });
pharmacySchema.index({ is_central_pharmacy: 1 });
pharmacySchema.index({ status: 1 });

// Helper method to check if pharmacy serves a hospital
pharmacySchema.methods.servesHospital = function(hospitalId) {
  if (this.is_global_pharmacy) return true;
  
  if (this.hospital_ids && this.hospital_ids.length > 0) {
    return this.hospital_ids.some(id => id.toString() === hospitalId.toString());
  }
  
  // Check if hospital belongs to any of the pharmacy's groups
  return false; // Would need population to check group membership
};

// Helper method to check if pharmacy serves a group
pharmacySchema.methods.servesGroup = function(groupId) {
  if (this.is_global_pharmacy) return true;
  
  if (this.group_ids && this.group_ids.length > 0) {
    return this.group_ids.some(id => id.toString() === groupId.toString());
  }
  
  return false;
};

module.exports = mongoose.model('Pharmacy', pharmacySchema);