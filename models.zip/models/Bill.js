const mongoose = require('mongoose');

const billSchema = new mongoose.Schema({
  // ADDED: Hospital context
  hospital_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital', 
    required: true 
  },
  
  patient_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Patient', 
    required: true 
  },
  appointment_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Appointment', 
    required: true 
  },
  bill_number: {
    type: String,
    unique: true
  },
  total_amount: { 
    type: Number, 
    required: true 
  },
  payment_method: { 
    type: String, 
    enum: ['Cash', 'Card', 'Insurance', 'UPI', 'Net Banking', 'Government Funded Scheme'], 
    required: true 
  },
  details: [{  
    description: String,
    amount: Number,
    quantity: { 
      type: Number, 
      default: 1 
    },
    category: {
      type: String,
      enum: ['consultation', 'room', 'medicine', 'lab_test', 'procedure', 'other']
    }
  }],
  status: { 
    type: String, 
    enum: ['Generated', 'Paid', 'Pending', 'Refunded', 'Cancelled'], 
    default: 'Generated' 
  },
  generated_at: { 
    type: Date, 
    default: Date.now 
  },
  paid_at: {
    type: Date
  },
  payment_reference: {
    type: String
  },
  created_by: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, { 
  timestamps: true 
});

// ADDED: Generate bill number with hospital context
billSchema.pre('save', async function(next) {
  if (this.isNew && !this.bill_number) {
    const hospital = await mongoose.model('Hospital').findById(this.hospital_id);
    if (!hospital) return next();
    
    const year = new Date().getFullYear().toString().slice(-2);
    const month = (new Date().getMonth() + 1).toString().padStart(2, '0');
    
    const count = await mongoose.model('Bill').countDocuments({
      hospital_id: this.hospital_id,
      generated_at: {
        $gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
        $lt: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1)
      }
    });
    
    this.bill_number = `BILL-${hospital.hospitalID}-${year}${month}-${(count + 1).toString().padStart(4, '0')}`;
  }
  next();
});

// ADDED: Index for hospital queries
billSchema.index({ hospital_id: 1 });
billSchema.index({ patient_id: 1 });
billSchema.index({ appointment_id: 1 });
billSchema.index({ status: 1 });
billSchema.index({ generated_at: -1 });

module.exports = mongoose.model('Bill', billSchema);