const mongoose = require('mongoose');

const saleItemSchema = new mongoose.Schema({
  medicine_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Medicine', 
    required: true 
  },
  batch_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'MedicineBatch' 
  },
  quantity: { type: Number, required: true, min: 1 },
  unit_price: { type: Number, required: true },
  discount: { type: Number, default: 0 }
});

const saleSchema = new mongoose.Schema({
  // ADDED: Hospital context
  hospital_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital', 
    required: true 
  },
  pharmacy_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Pharmacy' 
  },
  
  sale_number: { type: String, unique: true },
  patient_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Patient' 
  },
  customer_name: { type: String },
  customer_phone: { type: String },
  sale_date: { type: Date, default: Date.now },
  items: [saleItemSchema],
  subtotal: { type: Number, required: true },
  discount: { type: Number, default: 0 },
  tax: { type: Number, default: 0 },
  total_amount: { type: Number, required: true },
  payment_method: { 
    type: String, 
    enum: ['Cash', 'Card', 'UPI', 'Net Banking', 'Insurance'], 
    required: true 
  },
  status: { 
    type: String, 
    enum: ['Completed', 'Pending', 'Cancelled', 'Refunded'], 
    default: 'Completed' 
  },
  prescription_required: { type: Boolean, default: false },
  prescription_details: { type: String },
  created_by: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User' 
  }
}, { timestamps: true });

// UPDATED: Generate sale number with hospital context
saleSchema.pre('save', async function(next) {
  if (this.isNew && !this.sale_number) {
    const hospital = await mongoose.model('Hospital').findById(this.hospital_id);
    if (!hospital) return next();
    
    const year = new Date().getFullYear().toString().slice(-2);
    const month = (new Date().getMonth() + 1).toString().padStart(2, '0');
    
    const count = await mongoose.model('Sale').countDocuments({
      hospital_id: this.hospital_id,
      sale_date: {
        $gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
        $lt: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1)
      }
    });
    
    this.sale_number = `SALE-${hospital.hospitalID}-${year}${month}-${(count + 1).toString().padStart(4, '0')}`;
  }
  next();
});

// ADDED: Index for hospital queries
saleSchema.index({ hospital_id: 1 });
saleSchema.index({ pharmacy_id: 1 });

module.exports = mongoose.model('Sale', saleSchema);