const mongoose = require('mongoose');

const medicineBatchSchema = new mongoose.Schema({
  medicine_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Medicine', 
    required: true 
  },
  pharmacy_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Pharmacy', 
    required: true 
  },
  hospital_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital', 
    required: true 
  },
  batch_number: { 
    type: String, 
    required: true 
  },
  expiry_date: { 
    type: Date, 
    required: true 
  },
  manufacturing_date: { 
    type: Date, 
    required: true 
  },
  quantity: { 
    type: Number, 
    required: true, 
    min: 0 
  },
  available_quantity: {
    type: Number,
    min: 0,
    default: function() {
      return this.quantity;
    }
  },
  reserved_quantity: {
    type: Number,
    default: 0,
    min: 0
  },
  purchase_price: { 
    type: Number, 
    required: true 
  },
  selling_price: { 
    type: Number, 
    required: true 
  },
  mrp: {
    type: Number,
    required: true
  },
  supplier_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Supplier', 
    required: true 
  },
  purchase_order_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'PurchaseOrder'
  },
  purchase_date: { 
    type: Date, 
    default: Date.now 
  },
  received_date: { 
    type: Date 
  },
  location: {
    shelf: String,
    rack: String,
    bin: String
  },
  is_expired: {
    type: Boolean,
    default: false
  },
  is_active: { 
    type: Boolean, 
    default: true 
  }
}, { 
  timestamps: true 
});

// Compound index for batch uniqueness within hospital/pharmacy
medicineBatchSchema.index({ 
  hospital_id: 1, 
  pharmacy_id: 1, 
  medicine_id: 1, 
  batch_number: 1 
}, { unique: true });

// Indexes for better query performance
medicineBatchSchema.index({ hospital_id: 1 });
medicineBatchSchema.index({ pharmacy_id: 1 });
medicineBatchSchema.index({ medicine_id: 1 });
medicineBatchSchema.index({ supplier_id: 1 });
medicineBatchSchema.index({ expiry_date: 1 });
medicineBatchSchema.index({ is_expired: 1 });
medicineBatchSchema.index({ is_active: 1 });

// Pre-save middleware to update available quantity
medicineBatchSchema.pre('save', function(next) {
  this.available_quantity = this.quantity - this.reserved_quantity;
  
  // Check if batch is expired
  if (this.expiry_date && new Date() > this.expiry_date) {
    this.is_expired = true;
  }
  
  next();
});

// Virtual for days to expiry
medicineBatchSchema.virtual('days_to_expiry').get(function() {
  if (!this.expiry_date) return null;
  const today = new Date();
  const expiry = new Date(this.expiry_date);
  const diffTime = expiry - today;
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
});

module.exports = mongoose.model('MedicineBatch', medicineBatchSchema);