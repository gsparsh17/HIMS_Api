const mongoose = require('mongoose');

const paymentSchema = new mongoose.Schema({
  date: { type: Date, default: Date.now },
  amount: { type: Number, required: true },
  method: { 
    type: String, 
    enum: ['Cash', 'Card', 'UPI', 'Net Banking', 'Insurance', 'Government Scheme'],
    required: true 
  },
  reference: { type: String },
  status: { type: String, default: 'Completed' },
  collected_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
});

const serviceItemSchema = new mongoose.Schema({
  description: { type: String, required: true },
  quantity: { type: Number, default: 1 },
  total_price: { type: Number, required: true },
  tax_rate: { type: Number, default: 0 },
  tax_amount: { type: Number, default: 0 },
  service_type: { type: String, enum: ['Consultation', 'Procedure', 'Test', 'Other', 'Purchase'] }
});

const medicineItemSchema = new mongoose.Schema({
  medicine_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Medicine' },
  batch_id: { type: mongoose.Schema.Types.ObjectId, ref: 'MedicineBatch' },
  medicine_name: { type: String, required: true },
  batch_number: { type: String },
  expiry_date: { type: Date },
  quantity: { type: Number, required: true },
  unit_price: { type: Number, required: true },
  total_price: { type: Number, required: true },
  tax_rate: { type: Number, default: 0 },
  tax_amount: { type: Number, default: 0 },
  prescription_required: { type: Boolean, default: false },
  prescription_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Prescription' }
});

const invoiceSchema = new mongoose.Schema({
  // ADDED: Hospital context
  hospital_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital', 
    required: true 
  },
  pharmacy_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Pharmacy' 
  },
  
  invoice_number: { type: String, unique: true },
  
  // Customer Information
  patient_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Patient' },
  customer_type: { 
    type: String, 
    enum: ['Patient', 'Walk-in', 'Insurance', 'Corporate', 'Supplier', 'Other'], 
    required: true 
  },
  customer_name: { type: String },
  customer_phone: { type: String },
  customer_address: { type: String },
  
  // Reference Links
  appointment_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Appointment' },
  bill_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Bill' },
  sale_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Sale' },
  prescription_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Prescription' },
  purchase_order_id: { type: mongoose.Schema.Types.ObjectId, ref: 'PurchaseOrder' },
  
  // Invoice Type
  invoice_type: { 
    type: String, 
    enum: ['Appointment', 'Pharmacy', 'Mixed', 'Other', 'Purchase'], 
    required: true 
  },
  
  // Dates
  issue_date: { type: Date, default: Date.now },
  due_date: { type: Date, required: true },
  
  // Items
  service_items: [serviceItemSchema],
  medicine_items: [medicineItemSchema],
  
  // Financial details
  subtotal: { type: Number, required: true },
  discount: { type: Number, default: 0 },
  tax: { type: Number, default: 0 },
  total: { type: Number, required: true },
  
  // Payment tracking
  amount_paid: { type: Number, default: 0 },
  balance_due: { type: Number, default: function() { return this.total; } },
  payment_history: [paymentSchema],
  payment_method: {
    type: String,
    enum: ['Cash', 'Card', 'UPI', 'Net Banking', 'Insurance', 'Credit', 'Mixed']
  },
  
  // Status
  status: { 
    type: String, 
    enum: ['Draft', 'Issued', 'Paid', 'Partial', 'Overdue', 'Cancelled', 'Refunded'],
    default: 'Draft' 
  },
  
  // Additional fields
  notes: { type: String },
  terms_and_conditions: { type: String },
  created_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  
  // Pharmacy specific
  is_pharmacy_sale: { type: Boolean, default: false },
  dispensing_date: { type: Date },
  dispensed_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });

// Generate invoice number with hospital context
invoiceSchema.pre('save', async function(next) {
  try {
    if (this.isNew && !this.invoice_number) {
      const hospital = await mongoose.model('Hospital').findById(this.hospital_id);
      if (!hospital || !hospital.hospitalID) {
        throw new Error('Hospital not found or invalid hospital ID');
      }

      const year = new Date().getFullYear().toString().slice(-2);
      const month = (new Date().getMonth() + 1).toString().padStart(2, '0');
      const day = new Date().getDate().toString().padStart(2, '0');
      
      // Get count for this hospital today
      const startOfDay = new Date();
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date();
      endOfDay.setHours(23, 59, 59, 999);
      
      const count = await mongoose.model('Invoice').countDocuments({
        hospital_id: this.hospital_id,
        issue_date: {
          $gte: startOfDay,
          $lt: endOfDay
        }
      });

      // Different prefixes based on invoice type
      let prefix;
      switch(this.invoice_type) {
        case 'Pharmacy': prefix = 'PH'; break;
        case 'Appointment': prefix = 'APT'; break;
        case 'Purchase': prefix = 'PUR'; break;
        default: prefix = 'INV';
      }
      
      this.invoice_number = `${hospital.hospitalID}/${prefix}/${year}${month}${day}/${(count + 1).toString().padStart(4, '0')}`;
    }
    
    // Calculate balance due
    this.balance_due = this.total - this.amount_paid;
    
    // Auto-update status
    if (this.amount_paid >= this.total) {
      this.status = 'Paid';
    } else if (this.amount_paid > 0) {
      this.status = 'Partial';
    } else if (new Date() > this.due_date && this.status !== 'Paid') {
      this.status = 'Overdue';
    }
    
    // Auto-detect invoice type based on items
    if (this.medicine_items && this.medicine_items.length > 0) {
      this.is_pharmacy_sale = true;
      if (!this.invoice_type || this.invoice_type === 'Draft') {
        this.invoice_type = 'Pharmacy';
      }
    }
    
    next();
  } catch (error) {
    next(error);
  }
});

// Indexes for better performance
invoiceSchema.index({ hospital_id: 1 });
invoiceSchema.index({ pharmacy_id: 1 });
invoiceSchema.index({ invoice_number: 1 });
invoiceSchema.index({ patient_id: 1 });
invoiceSchema.index({ invoice_type: 1 });
invoiceSchema.index({ status: 1 });
invoiceSchema.index({ issue_date: -1 });
invoiceSchema.index({ hospital_id: 1, issue_date: -1 });
invoiceSchema.index({ hospital_id: 1, status: 1 });
invoiceSchema.index({ hospital_id: 1, patient_id: 1 });

// Virtuals
invoiceSchema.virtual('total_items').get(function() {
  return (this.service_items?.length || 0) + (this.medicine_items?.length || 0);
});

invoiceSchema.virtual('is_fully_paid').get(function() {
  return this.amount_paid >= this.total;
});

invoiceSchema.virtual('days_overdue').get(function() {
  if (this.status === 'Paid' || this.status === 'Draft') return 0;
  const today = new Date();
  const dueDate = new Date(this.due_date);
  const diffTime = today - dueDate;
  return Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
});

module.exports = mongoose.model('Invoice', invoiceSchema);