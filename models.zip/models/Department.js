const mongoose = require('mongoose');

const departmentSchema = new mongoose.Schema({
  hospital_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital', 
    required: true 
  },
  name: { 
    type: String, 
    required: true 
  },
  head_doctor_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Doctor' 
  },
  is_active: {
    type: Boolean,
    default: true
  }
});

// Compound unique index for hospital + department name
departmentSchema.index({ hospital_id: 1, name: 1 }, { unique: true });

module.exports = mongoose.model('Department', departmentSchema);