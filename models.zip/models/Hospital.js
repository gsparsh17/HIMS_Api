const mongoose = require('mongoose');

const hospitalSchema = new mongoose.Schema({
  group_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'HospitalGroup',
    required: true 
  },
  hospitalID: { 
    type: String, 
    required: true, 
    unique: true 
  },
  registryNo: { 
    type: String, 
    required: true 
  },
  hospitalName: { 
    type: String, 
    required: true 
  },
  companyName: { 
    type: String 
  },
  companyNumber: { 
    type: String 
  },
  name: { 
    type: String, 
    required: true 
  },
  address: { 
    type: String, 
    required: true 
  },
  contact: { 
    type: String, 
    required: true 
  },
  email: { 
    type: String, 
    required: true 
  },
  fireNOC: { 
    type: String 
  },
  policyDetails: { 
    type: String 
  },
  healthBima: { 
    type: String 
  },
  additionalInfo: { 
    type: String 
  },
  is_active: {
    type: Boolean,
    default: true
  },
  createdBy: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  }
}, { 
  timestamps: true 
});

hospitalSchema.pre('save', async function(next) {
  try {
    if (this.isNew) {
      const HospitalGroup = mongoose.model('HospitalGroup');
      
      if (!this.group_id) {
        const groupId = `GRP-${this.hospitalID}`;
        const personalGroup = await HospitalGroup.create({
          groupId: groupId,
          name: `${this.hospitalName} (Personal Group)`,
          type: 'personal',
          is_single_hospital: true,
          can_expand: true,
          address: this.address,
          contact_email: this.email,
          contact_phone: this.contact,
          created_by: this.createdBy
        });
        
        this.group_id = personalGroup._id;
      } else {
        const hospitalCount = await mongoose.model('Hospital').countDocuments({ 
          group_id: this.group_id 
        });
        
        if (hospitalCount > 0) {
          await HospitalGroup.findByIdAndUpdate(this.group_id, {
            type: 'chain',
            is_single_hospital: false
          });
        }
      }
    }
    
    next();
  } catch (error) {
    next(error);
  }
});

module.exports = mongoose.model('Hospital', hospitalSchema);