const mongoose = require('mongoose');

const supplierSchema = new mongoose.Schema({
  // Supplier can be linked to specific hospital, group, or be global
  hospital_ids: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital' 
  }],
  group_ids: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'HospitalGroup' 
  }],
  is_global_supplier: {
    type: Boolean,
    default: false
  },
  supplierId: {
    type: String,
    unique: true
  },
  name: {
    type: String,
    required: true,
    trim: true,
  },
  companyName: {
    type: String,
    trim: true,
  },
  contactPerson: {
    type: String,
    trim: true,
  },
  phone: {
    type: String,
    required: true,
    unique: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
  },
  address: {
    type: String,
  },
  supplier_type: {
    type: String,
    enum: ['medicine', 'equipment', 'consumables', 'general', 'pharmaceutical'],
    default: 'medicine'
  },
  tax_id: {
    type: String
  },
  payment_terms: {
    type: String,
    enum: ['Net 30', 'Net 60', 'Net 90', 'COD', 'Advance'],
    default: 'Net 30'
  },
  credit_limit: {
    type: Number,
    default: 0
  },
  rating: {
    type: Number,
    min: 1,
    max: 5,
    default: 3
  },
  isActive: {
    type: Boolean,
    default: true,
  }
}, { 
  timestamps: true 
});

// Generate supplier ID
supplierSchema.pre('save', async function (next) {
  try {
    if (!this.supplierId) {
      function generateSupplierId() {
        const prefix = 'SUP';
        const randomNum = Math.floor(1000 + Math.random() * 9000);
        return `${prefix}-${randomNum}`;
      }
      
      this.supplierId = generateSupplierId();
    }
    next();
  } catch (err) {
    next(err);
  }
});

// Indexes
supplierSchema.index({ hospital_ids: 1 });
supplierSchema.index({ group_ids: 1 });
supplierSchema.index({ is_global_supplier: 1 });
supplierSchema.index({ supplier_type: 1 });
supplierSchema.index({ isActive: 1 });

// Helper method to check if supplier serves a hospital
supplierSchema.methods.servesHospital = function(hospitalId) {
  if (this.is_global_supplier) return true;
  
  if (this.hospital_ids && this.hospital_ids.length > 0) {
    return this.hospital_ids.some(id => id.toString() === hospitalId.toString());
  }
  
  return false;
};

// Helper method to check if supplier serves a group
supplierSchema.methods.servesGroup = function(groupId) {
  if (this.is_global_supplier) return true;
  
  if (this.group_ids && this.group_ids.length > 0) {
    return this.group_ids.some(id => id.toString() === groupId.toString());
  }
  
  return false;
};

module.exports = mongoose.model('Supplier', supplierSchema);