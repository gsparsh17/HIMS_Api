const mongoose = require('mongoose');

const purchaseOrderItemSchema = new mongoose.Schema({
  medicine_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Medicine', 
    required: true 
  },
  quantity: { 
    type: Number, 
    required: true, 
    min: 1 
  },
  unit_cost: { 
    type: Number, 
    required: true 
  },
  total_cost: { 
    type: Number, 
    required: true 
  },
  received_quantity: {
    type: Number,
    default: 0,
    min: 0
  },
  batch_number: { 
    type: String 
  },
  expiry_date: { 
    type: Date 
  },
  selling_price: { 
    type: Number, 
    default: 0 
  },
  status: {
    type: String,
    enum: ['Pending', 'Partially Received', 'Received', 'Cancelled'],
    default: 'Pending'
  }
});

const purchaseOrderSchema = new mongoose.Schema({
  hospital_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Hospital',
    required: true
  },
  pharmacy_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Pharmacy'
  },
  order_number: { 
    type: String, 
    unique: true 
  },
  supplier_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Supplier', 
    required: true 
  },
  order_date: { 
    type: Date, 
    default: Date.now 
  },
  expected_delivery: { 
    type: Date 
  },
  status: { 
    type: String, 
    enum: ['Draft', 'Pending Approval', 'Approved', 'Ordered', 'Partially Received', 'Received', 'Cancelled', 'Closed'], 
    default: 'Draft' 
  },
  items: [purchaseOrderItemSchema],
  subtotal: { 
    type: Number, 
    required: true 
  },
  tax: { 
    type: Number, 
    default: 0 
  },
  shipping_charges: {
    type: Number,
    default: 0
  },
  discount: {
    type: Number,
    default: 0
  },
  total_amount: { 
    type: Number, 
    required: true 
  },
  payment_status: {
    type: String,
    enum: ['Pending', 'Partial', 'Paid'],
    default: 'Pending'
  },
  notes: { 
    type: String 
  },
  created_by: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User',
    required: true 
  },
  approved_by: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, { 
  timestamps: true 
});

// Generate order number before saving
purchaseOrderSchema.pre('save', async function(next) {
  if (this.isNew && !this.order_number) {
    const hospital = await mongoose.model('Hospital').findById(this.hospital_id);
    if (!hospital) {
      return next(new Error('Hospital not found'));
    }
    
    const year = new Date().getFullYear();
    const month = (new Date().getMonth() + 1).toString().padStart(2, '0');
    
    // Get count of purchase orders for this hospital this month
    const count = await mongoose.model('PurchaseOrder').countDocuments({
      hospital_id: this.hospital_id,
      createdAt: {
        $gte: new Date(year, new Date().getMonth(), 1),
        $lt: new Date(year, new Date().getMonth() + 1, 1)
      }
    });
    
    this.order_number = `PO-${hospital.hospitalID}-${year}${month}-${(count + 1).toString().padStart(4, '0')}`;
  }
  
  // Calculate subtotal from items
  if (this.items && this.items.length > 0) {
    this.subtotal = this.items.reduce((sum, item) => sum + item.total_cost, 0);
    this.total_amount = this.subtotal + this.tax + this.shipping_charges - this.discount;
  }
  
  next();
});

// Indexes
purchaseOrderSchema.index({ hospital_id: 1 });
purchaseOrderSchema.index({ pharmacy_id: 1 });
purchaseOrderSchema.index({ order_number: 1 });
purchaseOrderSchema.index({ supplier_id: 1 });
purchaseOrderSchema.index({ status: 1 });
purchaseOrderSchema.index({ order_date: 1 });
purchaseOrderSchema.index({ created_by: 1 });

// Helper method to calculate received percentage
purchaseOrderSchema.methods.getReceivedPercentage = function() {
  if (!this.items || this.items.length === 0) return 0;
  
  const totalOrdered = this.items.reduce((sum, item) => sum + item.quantity, 0);
  const totalReceived = this.items.reduce((sum, item) => sum + item.received_quantity, 0);
  
  return totalOrdered > 0 ? (totalReceived / totalOrdered) * 100 : 0;
};

// Helper method to update item status
purchaseOrderSchema.methods.updateItemStatus = function(itemIndex, receivedQuantity) {
  if (itemIndex >= 0 && itemIndex < this.items.length) {
    const item = this.items[itemIndex];
    item.received_quantity = receivedQuantity;
    
    if (receivedQuantity >= item.quantity) {
      item.status = 'Received';
    } else if (receivedQuantity > 0) {
      item.status = 'Partially Received';
    } else {
      item.status = 'Pending';
    }
    
    // Update overall order status
    this.updateOrderStatus();
  }
};

// Helper method to update overall order status
purchaseOrderSchema.methods.updateOrderStatus = function() {
  if (!this.items || this.items.length === 0) {
    this.status = 'Draft';
    return;
  }
  
  const allReceived = this.items.every(item => item.status === 'Received');
  const allPending = this.items.every(item => item.status === 'Pending');
  const anyReceived = this.items.some(item => item.status === 'Received' || item.status === 'Partially Received');
  const anyPartiallyReceived = this.items.some(item => item.status === 'Partially Received');
  
  if (allReceived) {
    this.status = 'Received';
  } else if (anyPartiallyReceived) {
    this.status = 'Partially Received';
  } else if (anyReceived) {
    this.status = 'Partially Received';
  } else if (!allPending && this.status !== 'Draft') {
    this.status = 'Ordered';
  }
};

module.exports = mongoose.model('PurchaseOrder', purchaseOrderSchema);