const mongoose = require('mongoose');

const hospitalChargesSchema = new mongoose.Schema({
  hospital_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital', 
    required: true 
  },
  group_wide: {
    type: Boolean,
    default: false
  },
  opdCharges: {
    registrationFee: { 
      type: Number, 
      default: 0 
    },
    consultationFee: { 
      type: Number, 
      default: 0 
    },
    discountType: { 
      type: String, 
      enum: ['Percentage', 'Fixed'], 
      default: 'Fixed' 
    },
    discountValue: { 
      type: Number, 
      default: 0 
    }
  },
  ipdCharges: {
    admissionFee: { 
      type: Number, 
      default: 0 
    },
    registrationFee: { 
      type: Number, 
      default: 0 
    },
    consultationFee: { 
      type: Number, 
      default: 0 
    },
    roomCharges: [{
      type: { 
        type: String, 
        enum: ['General', 'Semi-Private', 'Private', 'ICU'], 
        required: true 
      },
      chargePerDay: { 
        type: Number, 
        required: true 
      }
    }],
    nursingCharges: { 
      type: Number, 
      default: 0 
    },
    otCharges: { 
      type: Number, 
      default: 0 
    },
    discountType: { 
      type: String, 
      enum: ['Percentage', 'Fixed'], 
      default: 'Fixed' 
    },
    discountValue: { 
      type: Number, 
      default: 0 
    },
  },
  is_active: {
    type: Boolean,
    default: true
  },
  effectiveFrom: { 
    type: Date, 
    default: Date.now 
  }
}, { 
  timestamps: true 
});

// One hospital can have multiple charge entries over time
hospitalChargesSchema.index({ hospital_id: 1, effectiveFrom: -1 });
hospitalChargesSchema.index({ group_wide: 1 });

module.exports = mongoose.model('HospitalCharges', hospitalChargesSchema);