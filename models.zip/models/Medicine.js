const mongoose = require('mongoose');

const medicineSchema = new mongoose.Schema({
  hospital_ids: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital' 
  }],
  group_wide: {
    type: Boolean,
    default: false
  },
  medicineId: {
    type: String,
    unique: true
  },
  name: { 
    type: String, 
    required: true, 
    trim: true 
  },
  generic_name: { 
    type: String, 
    trim: true 
  },
  brand: { 
    type: String, 
    trim: true 
  },
  category: { 
    type: String, 
    required: true 
  },
  strength: { 
    type: String 
  },
  description: { 
    type: String 
  },
  min_stock_level: { 
    type: Number, 
    default: 10 
  },
  prescription_required: { 
    type: Boolean, 
    default: false 
  },
  location: {
    shelf: { 
      type: String 
    },
    rack: { 
      type: String 
    }
  },
  is_active: { 
    type: Boolean, 
    default: true 
  },
  created_at: { 
    type: Date, 
    default: Date.now 
  },
  updated_at: { 
    type: Date, 
    default: Date.now 
  }
});

medicineSchema.pre('save', function(next) {
  this.updated_at = Date.now();
  
  // Generate medicine ID if not present
  if (!this.medicineId) {
    function generateMedicineId() {
      const prefix = 'MED';
      const randomNum = Math.floor(10000 + Math.random() * 90000);
      return `${prefix}-${randomNum}`;
    }
    this.medicineId = generateMedicineId();
  }
  
  next();
});

// Indexes
medicineSchema.index({ hospital_ids: 1 });
medicineSchema.index({ group_wide: 1 });
medicineSchema.index({ name: 1 });
medicineSchema.index({ category: 1 });
medicineSchema.index({ is_active: 1 });

module.exports = mongoose.model('Medicine', medicineSchema);