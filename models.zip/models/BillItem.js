// const mongoose = require('mongoose');

// const billItemSchema = new mongoose.Schema({
//   bill_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Bill', required: true },
//   description: { type: String, required: true }, // e.g., Consultation, Medicine
//   amount: { type: Number, required: true }
// });

// module.exports = mongoose.model('BillItem', billItemSchema);
