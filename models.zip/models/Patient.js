const mongoose = require('mongoose');

const patientSchema = new mongoose.Schema({
  patientId: { 
    type: String, 
    unique: true 
  },
  hospital_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital', 
    required: true 
  },
  salutation: {
    type: String,
    enum: ['Mr.', 'Mrs.', 'Ms.', 'Miss', 'Dr.', 'Prof.', 'Baby', 'Master'],
  },
  first_name: { 
    type: String, 
    required: true 
  },
  last_name: { 
    type: String, 
    required: true 
  },
  email: { 
    type: String,
    unique: true 
  },
  phone: { 
    type: String, 
    required: true 
  },
  gender: { 
    type: String, 
    enum: ['male', 'female', 'other'], 
    required: true 
  },
  dob: { 
    type: Date, 
    required: true 
  },
  address: { 
    type: String 
  },
  city: { 
    type: String 
  },
  state: { 
    type: String 
  },
  zipCode: { 
    type: String 
  },
  emergency_contact: { 
    type: String 
  },
  emergency_phone: { 
    type: String 
  },
  medical_history: { 
    type: String 
  },
  allergies: { 
    type: String 
  },
  medications: { 
    type: String 
  },
  blood_group: {
    type: String,
    enum: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
  },
  patient_type: {
    type: String,
    enum: ['opd', 'ipd'],
    default: 'ipd',
  },
  is_active: {
    type: Boolean,
    default: true
  },
  registered_at: { 
    type: Date, 
    default: Date.now 
  },
});

// Helper function to generate structured patient ID
function generateStructuredPatientId(firstName, lastName, phone, hospitalCode) {
  const date = new Date();
  const year = date.getFullYear().toString().slice(-2);
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  
  const namePart = (firstName.substring(0, 3) + lastName.substring(0, 1)).toUpperCase();
  const phonePart = phone.slice(-4);
  
  return `${hospitalCode}-PAT-${namePart}${phonePart}-${year}${month}`;
}

patientSchema.pre('save', async function (next) {
  try {
    if (!this.patientId) {
      const hospital = await mongoose.model('Hospital').findById(this.hospital_id);
      if (!hospital || !hospital.hospitalID) {
        throw new Error('Hospital not found or invalid hospital ID');
      }

      this.patientId = generateStructuredPatientId(
        this.first_name,
        this.last_name,
        this.phone,
        hospital.hospitalID
      );
    }
    next();
  } catch (err) {
    next(err);
  }
});

// Indexes
patientSchema.index({ hospital_id: 1 });
patientSchema.index({ phone: 1 });
patientSchema.index({ email: 1 });
patientSchema.index({ patient_type: 1 });

module.exports = mongoose.model('Patient', patientSchema);