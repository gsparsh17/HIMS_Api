
require('./Customer');
require('./Medicine');
require('./Doctor');
require('./Patient');
require('./Prescription');
require('./Invoice');
require('./User');
require('./Department');
require('./Hospital');
// Add a require for every other model you have here