const mongoose = require('mongoose');

const staffSchema = new mongoose.Schema({
  hospital_ids: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital',
    required: true 
  }],
  primary_hospital_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital',
    required: true 
  },
  staffId: { 
    type: String, 
    unique: true 
  },
  first_name: { 
    type: String, 
    required: true 
  },
  last_name: { 
    type: String, 
    required: true 
  },
  email: { 
    type: String, 
    required: true, 
    unique: true 
  },
  phone: { 
    type: String, 
    required: true 
  },
  role: { 
    type: String, 
    required: true 
  },
  department: { 
    type: String 
  },
  specialization: { 
    type: String 
  },
  gender: { 
    type: String, 
    enum: ['male', 'female', 'other'] 
  },
  status: { 
    type: String, 
    enum: ['Active', 'Inactive', 'On Leave'], 
    default: 'Active' 
  },
  aadharNumber: { 
    type: String 
  },
  panNumber: { 
    type: String 
  },
  joined_at: { 
    type: Date, 
    default: Date.now 
  }
});

// Update pre-save hook
staffSchema.pre('save', async function (next) {
  try {
    if (!this.staffId) {
      const hospital = await mongoose.model('Hospital').findById(this.primary_hospital_id);
      if (!hospital || !hospital.hospitalID) {
        throw new Error('Primary hospital not found or invalid hospital ID');
      }

      function generateRandomCode(length = 4) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
          result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
      }

      this.staffId = `${hospital.hospitalID}-STAFF-${generateRandomCode(4)}`;
    }
    
    // Ensure primary_hospital_id is in hospital_ids array
    if (this.hospital_ids.length > 0 && !this.hospital_ids.includes(this.primary_hospital_id)) {
      this.hospital_ids.push(this.primary_hospital_id);
    }
    
    next();
  } catch (err) {
    next(err);
  }
});

// Indexes
staffSchema.index({ primary_hospital_id: 1 });
staffSchema.index({ hospital_ids: 1 });
staffSchema.index({ role: 1 });
staffSchema.index({ status: 1 });

// Virtual for backward compatibility
staffSchema.virtual('hospital_id').get(function() {
  return this.primary_hospital_id;
});

module.exports = mongoose.model('Staff', staffSchema);