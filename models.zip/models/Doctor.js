const mongoose = require('mongoose');

const doctorSchema = new mongoose.Schema({
  user_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  },
  hospital_ids: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital',
    required: true 
  }],
  primary_hospital_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital',
    required: true 
  },
  doctorId: { 
    type: String, 
    unique: true 
  },
  firstName: { 
    type: String, 
    required: true 
  },
  lastName: { 
    type: String, 
    required: true 
  },
  email: { 
    type: String, 
    required: true, 
    unique: true 
  },
  phone: { 
    type: String, 
    required: true 
  },
  dateOfBirth: { 
    type: Date 
  },
  gender: { 
    type: String, 
    enum: ['male', 'female', 'other'] 
  },
  address: { 
    type: String 
  },
  city: { 
    type: String 
  },
  state: { 
    type: String 
  },
  zipCode: { 
    type: String 
  },
  department: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Department', 
    required: true 
  },
  specialization: { 
    type: String 
  },
  licenseNumber: { 
    type: String, 
    required: true, 
    unique: true 
  },
  experience: { 
    type: Number 
  },
  education: { 
    type: String 
  },
  shift: { 
    type: String 
  },
  emergencyContact: { 
    type: String 
  },
  emergencyPhone: { 
    type: String 
  },
  startDate: { 
    type: Date 
  },
  isFullTime: { 
    type: Boolean, 
    default: true 
  },
  paymentType: { 
    type: String, 
    enum: ['Salary', 'Fee per Visit', 'Per Hour', 'Contractual Salary'], 
    required: true 
  },
  amount: { 
    type: Number, 
    required: true 
  },
  contractStartDate: { 
    type: Date, 
    default: null 
  },
  contractEndDate: { 
    type: Date, 
    default: null 
  },
  visitsPerWeek: { 
    type: Number, 
    default: null 
  },
  workingDaysPerWeek: [{ 
    type: String 
  }],
  timeSlots: [{
    start: { 
      type: String 
    },
    end: { 
      type: String 
    }
  }],
  aadharNumber: { 
    type: String 
  },
  panNumber: { 
    type: String 
  },
  notes: { 
    type: String 
  },
  is_active: {
    type: Boolean,
    default: true
  },
  joined_at: { 
    type: Date, 
    default: Date.now 
  }
});

// Generate doctor ID based on primary hospital
doctorSchema.pre('save', async function (next) {
  try {
    if (!this.doctorId) {
      const hospital = await mongoose.model('Hospital').findById(this.primary_hospital_id);
      if (!hospital || !hospital.hospitalID) {
        throw new Error('Primary hospital not found or invalid hospital ID');
      }

      function generateRandomCode(length = 4) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
          result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
      }

      this.doctorId = `${hospital.hospitalID}-DOC-${generateRandomCode(4)}`;
    }
    
    // Ensure primary_hospital_id is in hospital_ids array
    if (this.hospital_ids.length > 0 && !this.hospital_ids.includes(this.primary_hospital_id)) {
      this.hospital_ids.push(this.primary_hospital_id);
    }
    
    next();
  } catch (err) {
    next(err);
  }
});

// Indexes
doctorSchema.index({ primary_hospital_id: 1 });
doctorSchema.index({ hospital_ids: 1 });
doctorSchema.index({ department: 1 });
doctorSchema.index({ email: 1 });
doctorSchema.index({ licenseNumber: 1 });

// Virtual for backward compatibility
doctorSchema.virtual('hospital_id').get(function() {
  return this.primary_hospital_id;
});

module.exports = mongoose.model('Doctor', doctorSchema);