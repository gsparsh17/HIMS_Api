const mongoose = require('mongoose');

const customerSchema = new mongoose.Schema({
  hospital_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital', 
    required: true 
  },
  customerId: {
    type: String,
    unique: true
  },
  name: { 
    type: String, 
    required: true, 
    trim: true 
  },
  phone: { 
    type: String, 
    required: true
  },
  email: { 
    type: String, 
    lowercase: true 
  },
  address: { 
    type: String, 
    trim: true 
  },
  customer_type: {
    type: String,
    enum: ['Patient', 'Walk-in', 'Regular', 'Corporate', 'Insurance'],
    default: 'Walk-in'
  },
  patient_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Patient'
  },
  date_of_birth: { type: Date },
  gender: {
    type: String,
    enum: ['Male', 'Female', 'Other', 'Prefer not to say'],
    default: 'Prefer not to say'
  },
  blood_group: {
    type: String,
    enum: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'Unknown']
  },
  allergies: [String],
  medical_conditions: [String],
  
  // Contact Preferences
  contact_preferences: {
    sms: { type: Boolean, default: true },
    email: { type: Boolean, default: false },
    whatsapp: { type: Boolean, default: true }
  },
  loyalty_points: { type: Number, default: 0 },
  total_spent: { type: Number, default: 0 },
  
  // Status & Metadata
  is_active: { type: Boolean, default: true },
  notes: { type: String },
  created_by: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User' 
  }
}, { 
  timestamps: true 
});

// Generate customer ID based on hospital
customerSchema.pre('save', async function (next) {
  try {
    if (!this.customerId) {
      const hospital = await mongoose.model('Hospital').findById(this.hospital_id);
      if (!hospital || !hospital.hospitalID) {
        throw new Error('Hospital not found or invalid hospital ID');
      }

      function generateRandomCode(length = 4) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
          result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
      }

      this.customerId = `${hospital.hospitalID}-CUST-${generateRandomCode(4)}`;
    }
    
    // Compound index for phone within hospital
    next();
  } catch (err) {
    next(err);
  }
});

// Index for better query performance - unique phone within hospital
customerSchema.index({ hospital_id: 1, phone: 1 }, { unique: true });
customerSchema.index({ hospital_id: 1, email: 1 }, { sparse: true });
customerSchema.index({ patient_id: 1 }, { sparse: true });
customerSchema.index({ customer_type: 1 });
customerSchema.index({ is_active: 1 });

// Virtual for age calculation
customerSchema.virtual('age').get(function() {
  if (!this.date_of_birth) return null;
  const today = new Date();
  const birthDate = new Date(this.date_of_birth);
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age;
});

module.exports = mongoose.model('Customer', customerSchema);