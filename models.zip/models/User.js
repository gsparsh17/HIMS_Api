const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name: { 
    type: String, 
    required: true 
  },
  email: { 
    type: String, 
    required: true, 
    unique: true 
  },
  password: { 
    type: String, 
    required: true 
  },
  role: { 
    type: String, 
    enum: ['super_admin', 'admin', 'doctor', 'nurse', 'staff', 'pharmacy', 'patient'], 
    required: true 
  },
  group_ids: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'HospitalGroup' 
  }],
  hospital_ids: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital' 
  }],
  primary_hospital_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital' 
  },
  group_access: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'HospitalGroup'
  },
  resetPasswordToken: String,
  resetPasswordExpire: Date,
  is_active: { 
    type: Boolean, 
    default: true 
  }
}, { 
  timestamps: true 
});

// Hash password before saving
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

// Compare hashed password
userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

// Set primary hospital if only one hospital in array
userSchema.pre('save', function(next) {
  if (this.hospital_ids && this.hospital_ids.length === 1 && !this.primary_hospital_id) {
    this.primary_hospital_id = this.hospital_ids[0];
  }
  next();
});

// Indexes for better performance
userSchema.index({ email: 1 });
userSchema.index({ role: 1 });
userSchema.index({ primary_hospital_id: 1 });
userSchema.index({ group_access: 1 });

// Virtual for backward compatibility
userSchema.virtual('hospital_id').get(function() {
  return this.primary_hospital_id;
});

userSchema.virtual('group_id').get(function() {
  return this.group_access;
});

module.exports = mongoose.model('User', userSchema);