const mongoose = require('mongoose');

const bookedPatientSchema = new mongoose.Schema({
  patient_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Patient', 
    required: true 
  },
  serialNumber: { 
    type: Number, 
    required: true 
  },
  appointment_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Appointment' 
  }
});

const doctorDaySchema = new mongoose.Schema({
  doctor_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Doctor', 
    required: true 
  },
  bookedAppointments: [{
    startTime: { 
      type: Date, 
      required: true 
    },
    endTime: { 
      type: Date, 
      required: true 
    },
    duration: { 
      type: Number, 
      required: true 
    },
    appointment_id: { 
      type: mongoose.Schema.Types.ObjectId, 
      ref: 'Appointment' 
    },
    status: { 
      type: String, 
      enum: ['Available','Scheduled', 'InProgress', 'Completed', 'Cancelled'],
      default: 'Scheduled'
    }
  }],
  bookedPatients: [bookedPatientSchema],
  breaks: [{
    startTime: { 
      type: Date, 
      required: true 
    },
    endTime: { 
      type: Date, 
      required: true 
    },
    reason: String
  }]
});

const calendarDaySchema = new mongoose.Schema({
  date: { 
    type: Date, 
    required: true 
  },
  dayName: String,
  doctors: [doctorDaySchema]
});

const calendarSchema = new mongoose.Schema({
  hospital_id: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Hospital', 
    required: true 
  },
  days: [calendarDaySchema]
});

// Indexes for efficient queries
calendarSchema.index({ hospital_id: 1 });
calendarSchema.index({ 'days.date': 1 });
calendarSchema.index({ hospital_id: 1, 'days.date': 1 });

module.exports = mongoose.model('Calendar', calendarSchema);